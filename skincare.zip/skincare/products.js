// Sample product data (replace with your actual products)
const products = [
    {
        name: "Product 1",
        description: "Description for Product 1.",
        image: "product1.jpg",
    },
    {
        name: "Product 2",
        description: "Description for Product 2.",
        image: "product2.jpg",
    },
    // Add more products as needed
];

// Function to generate product cards
function generateProductCards(products) {
    const productsSection = document.getElementById("productsSection");

    products.forEach(product => {
        const productCard = document.createElement("div");
        productCard.className = "product-card";

        const productImage = document.createElement("img");
        productImage.src = product.image;
        productImage.alt = product.name;
        productImage.className = "product-image";

        const productName = document.createElement("h2");
        productName.textContent = product.name;

        const productDescription = document.createElement("p");
        productDescription.textContent = product.description;

        const addToCartButton = document.createElement("a");
        addToCartButton.href = "#"; // Add your cart functionality here
        addToCartButton.className = "add-to-cart-button";
        addToCartButton.textContent = "Add to Cart";

        productCard.appendChild(productImage);
        productCard.appendChild(productName);
        productCard.appendChild(productDescription);
        productCard.appendChild(addToCartButton);

        productsSection.appendChild(productCard);
    });
}

// Call the function to generate product cards when the page loads
window.onload = function() {
    generateProductCards(products);
};

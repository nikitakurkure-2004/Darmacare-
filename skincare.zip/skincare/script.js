const skinTypeForm = document.getElementById("skinTypeForm");
const productSuggestions = document.getElementById("productSuggestions");

skinTypeForm.addEventListener("submit", function(event) {
    event.preventDefault();
    // Fetch product suggestions based on form data
    // Display product suggestions in productSuggestions div
    // Example: fetchProducts(formData.skinType);
});

// Function to fetch product suggestions based on skin type
function fetchProducts(skinType) {
    // Make an API request to fetch product suggestions based on skinType
    // Example: 
    // fetch(`/api/products?skinType=${skinType}`)
    //     .then(response => response.json())
    //     .then(products => {
    //         displayProducts(products);
    //     })
    //     .catch(error => {
    //         console.error("Error fetching products:", error);
    //     });
}

// Function to display product suggestions
function displayProducts(products) {
    productSuggestions.innerHTML = "";
    products.forEach(product => {
        const productDiv = document.createElement("div");
        productDiv.classList.add("product");
        productDiv.textContent = product.name; // You can modify this to display product details
        productSuggestions.appendChild(productDiv);
    });
}
